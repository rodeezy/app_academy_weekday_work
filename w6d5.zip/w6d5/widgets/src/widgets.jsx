import React from 'react';
import ReactDOM from 'react-dom';

import Tabs from './tabs';
// import component files if needed

document.addEventListener('DOMContentLoaded', () => {
  ReactDOM.render(<Tabs />, document.getElementById('gage'));
});


// ReactDOM.render(<Tabs />, document.getElementById('gage'));
